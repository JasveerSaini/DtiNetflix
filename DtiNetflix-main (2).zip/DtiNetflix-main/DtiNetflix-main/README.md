# EcNet
Streaming Service with E-Commerce platform support

## instructions to run

### HTTP-SERVER Dependency
```npm install -g http-server```

### Starting the server
```npm start```